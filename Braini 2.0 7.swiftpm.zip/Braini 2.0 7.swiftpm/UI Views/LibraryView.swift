import SwiftUI
import PhotosUI
//Source for saving images to filesystem: https://www.hackingwithswift.com/example-code/media/how-to-save-a-uiimage-to-a-file-using-jpegdata-and-pngdata

struct LibraryView: View{
    @Binding var user: User
    @Binding var showingLibrary: Bool
    @Binding var libraryFilled: Bool
    @State private var showingSignup = false
    @State private var showingLogin = false
    @State private var showingPhotoPicker = false
    @State private var addedImage = false
    @State private var selectedItem: PhotosPickerItem? = nil
    @State private var selectedImage: Data? = nil
    @State private var uiImage: UIImage? = nil
    @State private var donePickingPhotos = false
    @State private var nameForImage = ""
    
    
    var body: some View{
        if user.name != "" && !showingSignup && !showingLogin{
            HStack{}.padding(.bottom, 70)
            HStack{
                Text("Welcome to your library, ")
                    .font(.largeTitle)
                Text("\(user.name) 🧠")
                    .font(.largeTitle)
                    .fontWeight(.semibold)
                    .foregroundColor(Color.indigo)
                
            }.padding(.bottom, 20)
                .onAppear{
                    print(user.name)
                    toggleShowingLibrary()
                }
        }
        else {
            HStack{}.padding(.bottom, 70)
            VStack{
                HStack{
                    Text("Welcome to your")
                        .font(.largeTitle)
                    Text("Braini Library!")
                        .font(.largeTitle)
                        .fontWeight(.semibold)
                        .foregroundColor(Color.indigo)
                }.padding(.bottom, 30)
                HStack{
                    Button("Sign up", action: signUp)
                        .buttonStyle(.bordered)
                        .background(Color.indigo)
                        .cornerRadius(10)
                        .foregroundColor(Color.white)
                        .sheet(isPresented: $showingSignup){
                            SignupView(user: $user, showingSignup: $showingSignup)
                        }
                    Button("Log in", action: login)
                        .buttonStyle(.bordered)
                        .background(Color.indigo)
                        .cornerRadius(10)
                        .foregroundColor(Color.white)
                        .sheet(isPresented: $showingLogin){
                            LoginView(user: $user, showingLogin: $showingLogin)
                        }
                }.padding(.bottom, 30)
            }
        }
        if !donePickingPhotos{
            VStack{
                Text("This is where you can add and delete photos you want to remember.")
                    .padding(.bottom, 20)
                Text("We've added some stock photos for your convenience--feel free to replace them with your own.")
                    .padding(.bottom, 20)
                Text("If you're signed in, your photo library will be saved locally on your device.")
                    .padding(.bottom, 20)
                Text("You can also play as a guest, but your photo library will only be retained until you close the app.")
                    .padding(.bottom, 20)
                Button("Add New Image", action: pickPhoto)
                    .buttonStyle(.bordered)
                    .background(Color.indigo)
                    .cornerRadius(10)
                    .foregroundColor(Color.white)
                    .sheet(isPresented: $showingPhotoPicker){
                        PhotoPickerView(selectedItem: $selectedItem, donePickingPhotos: $donePickingPhotos, selectedImage: $selectedImage, uiImage: $uiImage)
                    }
            }
        }
        else if !addedImage{
            Text("Name your image")
                .font(.largeTitle)
            let image = Image(uiImage: uiImage ?? UIImage())
            image.resizable()
                .scaledToFit()
                .frame(width: 300, height: 300)
                .padding(.bottom, 20)
            TextField("name", text: $nameForImage)
                .padding(.bottom, 20)
                .frame(width: 200, height: 20)
                .textFieldStyle(.roundedBorder)
            Button("Done", action: addImage)
                .buttonStyle(.bordered)
                .background(Color.indigo)
                .cornerRadius(10)
                .foregroundColor(Color.white)
        }
        //Show list of images and names here
        //(possibly with delete functionality)
        //This will require getting images from the filesystem
        List{
            ForEach(user.memories){memory in
                HStack{
                    Image(uiImage: UIImage(contentsOfFile: memory.imagePath.path) ?? UIImage())
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250, height: 250)
                        .padding(.bottom, 20)
                        .padding(.trailing, 20)
                    Text(memory.name)
                        .font(.title)
                        .fontWeight(.semibold)
                    
                }
            }.onDelete{ indexSet in
                user.memories.remove(atOffsets: indexSet)
                saveUserToDefaults(user: user)
            }
        }
        
    }
    
    func unimplemented(){
        print("Not implemented yet")
    }
    func toggleShowingLibrary(){
        showingLibrary = false
    }
    func signUp(){
        showingSignup = true
    }
    func login(){
        showingLogin = true
    }
    func pickPhoto(){
        donePickingPhotos = false
        addedImage = false
        showingPhotoPicker = true
        selectedItem = nil
        selectedImage = nil
        uiImage = nil
    }
    func addImage(){
        //Handle adding name/image pair to user defaults
        //(Need to save images to local filesystem and save path to defaults)
        print(nameForImage)

        if let data = uiImage?.pngData() {
            let filename = getDocumentsDirectory().appendingPathComponent("\(nameForImage).png")
            try? data.write(to: filename)
            let newPair = NameImagePair(name: nameForImage, imagePath: filename)
            user.memories.append(newPair)
            if user.name != ""{
                saveUserToDefaults(user: user)
                print(getUserFromDefaults(username: user.username))
            }
            print(newPair.imagePath.absoluteString)
            
        }
        addedImage = true
        donePickingPhotos = false
        showingPhotoPicker = false
    }
    func getDocumentsDirectory() -> URL {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        return paths[0]
    }
    
}
