import SwiftUI
import Foundation
import Charts

//Attribution:
//https://useyourloaf.com/blog/swiftui-pie-charts/
//https://www.reddit.com/r/SwiftUI/comments/zquvr5/why_dont_i_see_the_legend_displayed_for_this/

struct GameFinishedView: View{
    @Binding var selectedPairs: [NameImagePair]
    @Binding var cards: [Card]
    @Binding var masterFlip: Bool
    @Binding var selectedCards: [Card]
    @Binding var gameStarted: Bool
    @Binding var done: Bool
    @Binding var elapsedTimeSec: Int
    @Binding var numCorrectPairs: Double
    @Binding var numAttemptedPairs: Double
    var body: some View{
        VStack{
            Text("Awesome job! 🎉🎉🎉")
                .font(.largeTitle)
                .fontWeight(.semibold)
                .padding(.bottom, 10)
            Text("You sharpened your memory with Braini.")
                .font(.headline)
                .padding(.bottom, 30)
            HStack{
                Text("You finished in")
                    .font(.title)
                Text("\(elapsedTimeSec)")
                    .font(.title)
                    .fontWeight(.semibold)
                    .foregroundColor(Color.indigo)
                Text("seconds")
                    .font(.title)
            }.padding(.bottom, 30)
            Chart() {
                SectorMark(
                    angle: .value("Correct matches", numCorrectPairs),
                    innerRadius: .ratio(0.7)
                ).foregroundStyle(Color.green)
                SectorMark(
                    angle: .value("Incorrect matches", numAttemptedPairs - numCorrectPairs),
                    innerRadius: .ratio(0.7)
                ).foregroundStyle(Color.red)
              
            }.chartLegend(position: .overlay, alignment: .center, content: {
                VStack{
                    Text("\(numCorrectPairs/numAttemptedPairs * 100)% Correct matches").foregroundColor(Color.green)
                    Text("\((1 - numCorrectPairs/numAttemptedPairs) * 100)% Incorrect matches").foregroundColor(Color.red)
                }
            }).chartForegroundStyleScale(["Correct matches": Color.green, "Incorrect matches": Color.red])
                .scaledToFit()
                .frame(height: 400)
                .padding(.bottom, 50)
                .font(.headline)
        
            
            Button(action: {playAgain()}) {
                Text("Play Again")
                    .frame(width: 200, height: 75)
                    .font(.title)
            }.background(Color.indigo)
                .cornerRadius(10)
                .foregroundColor(Color.white)
        }
    }
    func playAgain(){
        selectedPairs = []
        cards = []
        masterFlip = true
        selectedCards = []
        gameStarted = false
        done = false
        numCorrectPairs = 0
        numAttemptedPairs = 0
        elapsedTimeSec = 0
    }
}
