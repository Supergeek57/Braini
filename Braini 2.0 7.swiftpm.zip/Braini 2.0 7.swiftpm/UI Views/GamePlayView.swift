import SwiftUI
import Foundation

struct GamePlayView: View{
    @Binding var pairs: [NameImagePair]
    @Binding var cards: [Card]
    @Binding var masterFlip: Bool
    @Binding var selectedCards: [Card]
    @Binding var done: Bool
    @Binding var timer: Timer?
    @Binding var elapsedTimeSec: Int
    @State private var numSelectedCards = 0
    @Binding var numCorrectPairs: Double
    @Binding var numAttemptedPairs: Double
    @State private var index = 0
    
    let columns = [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())]
    var body: some View{
        ScrollView{
            Text("After the cards flip over, match names with images by clicking on them!")
                .font(.headline)
                .padding(.bottom, 20)
            LazyVGrid(columns: columns){
                ForEach(cards){ card in
                    if selectedCards.contains(where: {$0 == card}) || masterFlip {
                        if card.cardType == 0{
                            Button{
                                flip(card: card)
                            } label: {
                                Image(uiImage: UIImage(contentsOfFile: card.pair.imagePath.path) ?? UIImage())
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 350, height: 350)
                            }.disabled(selectedCards.contains(where: {$0 == card}))
                            
                        }
                        else{
                            Button{
                                flip(card: card)
                            } label: {
                                Text(card.pair.name)
                                    .font(.largeTitle)
                                    .fontWeight(.semibold)
                                    .foregroundColor(Color.white)
                                    .background(
                                        RoundedRectangle(cornerRadius: 20, style: .continuous).fill(Color.indigo).frame(width: 250, height: 350)
                                    ).frame(width: 250, height: 350)
                            }.disabled(selectedCards.contains(where: {$0 == card}))
                        
                        }
                    }
                    else{
                        Button{
                            flip(card: card)
                        } label: {
                            Text("🧠")
                                .font(.largeTitle)
                                .background(
                                    RoundedRectangle(cornerRadius: 20, style: .continuous).fill(Color.gray).frame(width: 250, height: 350)
                                ).frame(width: 250, height: 350)
                        }
                        
                        
                    }
                    
                }
            }
        }.onAppear{
            var nameCard: Card
            var imageCard: Card
            for pair in pairs{
                nameCard = Card(cardType: 1, pair: pair)
                imageCard = Card(cardType: 0, pair: pair)
                cards.append(nameCard)
                cards.append(imageCard)
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                masterFlip = false
            }
            
        }.onChange(of: numSelectedCards){
            print("checking selected")
            checkSelected()
        }
    }
    func flip(card: Card) -> Void{
        if !selectedCards.contains(where: {$0 == card}){
            //card.flip()
            numSelectedCards += 1
            selectedCards.append(card)
            //print(selectedCards)
            //print("isFlipped is \(card.getFlipped())")
        }
        else{
            //card.flip()
            numSelectedCards -= 1
            selectedCards.removeAll(where: {$0.id == card.id})
            //print(selectedCards)
            //remove card from selected cards array
            //print("isFlipped is \(card.getFlipped())")
        }
    }
    func checkSelected(){
        if numSelectedCards == 2{
            //Check if it's a match
            if selectedCards[index].pair == selectedCards[index + 1].pair{
                //Yay, correct match!
                print("Match")
                numCorrectPairs += 1
                numSelectedCards = 0
                print("Num correct pairs: \(numCorrectPairs)")
                index += 2
                if Int(numCorrectPairs) == cards.count/2{
                    //All pairs are correct--done with the game :)
                    print("Done")
                    timer?.invalidate()
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                        done = true
                    }
                }
            }
            else{
                //Flip the cards back
                print("No match")
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                    selectedCards.remove(at: selectedCards.count - 1)
                    selectedCards.remove(at: selectedCards.count - 1)
                    numSelectedCards = 0
                }
            }
            numAttemptedPairs += 1
        }
        else{
            print("num selected: \(numSelectedCards)")
        }
    }
}
