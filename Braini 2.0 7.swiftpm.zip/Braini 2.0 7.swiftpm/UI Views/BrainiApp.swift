import SwiftUI

@main
struct BrainiApp: App {
    @State private var libraryFilled = false
    var body: some Scene {
        WindowGroup {
            ContentView(libraryFilled: $libraryFilled)
        }
    }
}
