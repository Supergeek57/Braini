import SwiftUI
import PhotosUI
//Attribution: https://stackoverflow.com/questions/57022615/select-multiple-items-in-swiftui-list
//https://medium.com/@iOSchandra0/how-to-create-a-stopwatch-in-swift-5-viewcontroller-viewmodel-swiftui-cefa5c5e3d0 

struct LibraryPickerView: View{
    @Binding var user: User
    @Binding var selectedPairs: [NameImagePair]
    @Binding var gameStarted: Bool
    @Binding var masterFlip: Bool
    @Binding var showingLibPicker: Bool
    @Binding var timer: Timer?
    @Binding var elapsedTimeSec: Int
    
    var body: some View{
        //Show list of images and names here with picker
        //This will require getting images from the filesystem
        Text("Click on images to select them for the game, then click 'Start Game' when you're ready to play!")
            .font(.headline)
            .padding(.bottom, 20)
        List{
            ForEach(user.memories){memory in
                MultiSelectItem(memory: memory, isSelected: selectedPairs.contains(memory)){
                    if selectedPairs.contains(memory){
                        selectedPairs.removeAll(where: {$0 == memory})
                        //print(selectedPairs)
                    }
                    else{
                        selectedPairs.append(memory)
                        //print(selectedPairs)
                    }
                }
            }
        }
        Button(action: {startGame()}) {
            Text("Start Game")
                .frame(width: 200, height: 75)
                .font(.title)
        }.background(Color.indigo)
            .cornerRadius(10)
            .foregroundColor(Color.white)
        
    }
    
    func startGame(){
        //Start timer
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true, block: { timer in
            // Start incrementing the timer by 1 second
            self.elapsedTimeSec += Int(timer.timeInterval)
        })
        gameStarted = true
        showingLibPicker = false
    }
    
}
