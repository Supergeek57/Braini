import SwiftUI

struct MainGameView: View{
    @State private var done = false
    @State private var showingLibPicker = false
    @State private var selectedPairs: [NameImagePair] = []
    @State private var gameStarted: Bool = false
    @State private var cards: [Card] = []
    @State private var masterFlip: Bool = true
    @State private var selectedCards: [Card] = []
    @State private var timer: Timer?
    @State private var elapsedTimeSec = 0
    @State private var numCorrectPairs = 0.0
    @State private var numAttemptedPairs = 0.0
    @Binding var user: User
    @Binding var showingLibrary: Bool
    @Binding var libraryFilled: Bool
    var body: some View{
        if user.name != "" && !done {
            HStack{
                Text("Welcome back, ")
                    .font(.largeTitle)
                Text("\(user.name) 🧠")
                    .font(.largeTitle)
                    .fontWeight(.semibold)
                    .foregroundColor(Color.indigo)
                
            }.padding(.bottom, 20)
        }
        else if !done{
            HStack{
                Text("Welcome to")
                    .font(.largeTitle)
                Text("Braini 🧠")
                    .font(.largeTitle)
                    .fontWeight(.semibold)
                    .foregroundColor(Color.indigo)
                
            }.padding(.bottom, 20)
        }
        if !gameStarted && !done && !showingLibPicker {
            VStack{
                HStack{
                    Text("The image-based memory game for")
                        .font(.title)
                        .fontWeight(.semibold)
                    Text("everyone")
                        .font(.title)
                        .foregroundColor(Color.indigo)
                        .fontWeight(.semibold)
                }.padding(.bottom, 20)
                Text("Keep running into someone but can't remember their name?")
                    .padding(.bottom, 10)
                Text("Need to memorize cell anatomy diagrams for tomorrow's bio exam?")
                    .padding(.bottom, 10)
                Text("We got you!")
                    .padding(.bottom, 20)
                    .font(.title)
                    .fontWeight(.semibold)
                Text("Build your memory by playing a simple game where you match names with pictures. It's easy and fun!")
                    .padding(.bottom, 10)
                Text("Click Play Now to play with stock photos, or go to your library to add photos from your gallery.")
                    .padding(.bottom, 20)
                HStack{
                    NavigationLink(destination: LibraryView(user: $user, showingLibrary: $showingLibrary, libraryFilled: $libraryFilled), isActive: $showingLibrary){
                        Button(action: {showBrainiLibrary()}) {
                            Text("Go to Braini Library")
                                .frame(width: 200, height: 75)
                                .font(.title)
                        }.background(Color.indigo)
                            .cornerRadius(10)
                            .foregroundColor(Color.white)
                        Button(action: showLibrary){
                            Text("New Game")
                                .font(.title)
                                .frame(width: 200, height: 75)
                        }.background(Color.indigo)
                            .cornerRadius(10)
                            .foregroundColor(Color.white)
                    }
               
                }
                
            }
        }
        if !gameStarted && !done && showingLibPicker{
            LibraryPickerView(user: $user, selectedPairs: $selectedPairs, gameStarted: $gameStarted, masterFlip: $masterFlip, showingLibPicker: $showingLibPicker, timer: $timer, elapsedTimeSec: $elapsedTimeSec)
            //LibraryImportView()
        }
        if gameStarted && !done{
            GamePlayView(pairs: $selectedPairs, cards: $cards, masterFlip: $masterFlip, selectedCards: $selectedCards, done: $done, timer: $timer, elapsedTimeSec: $elapsedTimeSec, numCorrectPairs: $numCorrectPairs, numAttemptedPairs: $numAttemptedPairs)
        }
        if done{
            GameFinishedView(selectedPairs: $selectedPairs, cards: $cards, masterFlip: $masterFlip, selectedCards: $selectedCards, gameStarted: $gameStarted, done: $done, elapsedTimeSec: $elapsedTimeSec, numCorrectPairs: $numCorrectPairs, numAttemptedPairs: $numAttemptedPairs)
        }
        
    }
    
    func showLibrary(){
        showingLibPicker = true
    }
    func showBrainiLibrary(){
        showingLibrary = true
    }
}
