import SwiftUI
import CryptoKit

struct SignupView: View{
    @Binding var user: User
    @Binding var showingSignup: Bool
    @State private var password = ""
    @State private var name = ""
    @State private var username = ""
    var body: some View{
        VStack{
            Form{
                Text("Sign Up for Braini")
                    .font(.largeTitle)
                    .fontWeight(.semibold)
                    .foregroundColor(Color.indigo)
                TextField("name", text: $name)
                    .textFieldStyle(.roundedBorder)
                    .frame(width: 500, height: 30)
                TextField("username", text: $username)
                    .textFieldStyle(.roundedBorder)
                    .frame(width: 500, height: 30)
                SecureField("password", text: $password)
                    .textFieldStyle(.roundedBorder)
                    .frame(width: 500, height: 30)
                HStack{
                    Button("Sign Up", action: handleSignup)
                        .buttonStyle(.bordered)
                        .background(Color.indigo)
                        .cornerRadius(10)
                        .foregroundColor(Color.white)
                        .padding(.top, 20) 
                    Button("Cancel", action: dismiss)
                        .buttonStyle(.bordered)
                        .background(Color.red)
                        .cornerRadius(10)
                        .foregroundColor(Color.white)
                        .padding(.top, 20) 
                    
                }
                
            }
        }.background(Color.white)
    }
    
    func handleSignup(){
        print("Handle signup")
        //Hash password and add hashed password to user
        let hashedPassword = hashPassword(password)
        user.hashedPassword = hashedPassword
        user.name = name
        user.username = username
        print(user.username)
        //Add user with username and (hashed) password to user defaults
        saveUserToDefaults(user: user)
        showingSignup = false
    }
    func hashPassword(_ password: String) -> String {
        let hash = SHA256.hash(data: Data(password.utf8))
        return hash.compactMap { String(format: "%02x", $0) }.joined()
    }
    func dismiss(){
        showingSignup = false
    }
}
