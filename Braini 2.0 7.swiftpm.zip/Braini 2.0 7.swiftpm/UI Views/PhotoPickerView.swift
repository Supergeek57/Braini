import SwiftUI
import PhotosUI

//Source: https://www.hackingwithswift.com/quick-start/swiftui/how-to-let-users-select-pictures-using-photospicker

struct PhotoPickerView: View {
    @Binding var selectedItem: PhotosPickerItem?
    @Binding var donePickingPhotos: Bool
    @Binding var selectedImage: Data?
    @Binding var uiImage: UIImage?
    var body: some View {
            PhotosPicker("Choose a photo", selection: $selectedItem)
            .onChange(of: selectedItem) {
                Task {
                    do{
                        if let loaded = try? await selectedItem?.loadTransferable(type: Data.self) {
                            selectedImage = loaded
                        } else {
                            print("Couldn't fetch image")
                        }
                        uiImage = UIImage(data: selectedImage ?? Data())
                        donePickingPhotos = true
                    }
                    //catch{
                    //    print("\(error)")
                    //}
                    
                }
            }
    }
    
}
