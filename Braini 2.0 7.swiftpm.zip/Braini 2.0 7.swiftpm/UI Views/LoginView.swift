import SwiftUI
import CryptoKit

struct LoginView: View{
    @Binding var user: User
    @Binding var showingLogin: Bool
    @State private var password = ""
    @State private var username = ""
    @State private var usernameNotFound = false
    @State private var incorrectPassword = false

    var body: some View{
        Form{
            Text("Log In")
                .font(.largeTitle)
                .fontWeight(.semibold)
                .foregroundColor(Color.indigo)
            TextField("username", text: $username)
            SecureField("password", text: $password)
            HStack{
                Button("Login", action: handleLogin)
                    .buttonStyle(.bordered)
                    .background(Color.indigo)
                    .cornerRadius(10)
                    .foregroundColor(Color.white)
                Button("Cancel", action: dismiss)
                    .buttonStyle(.bordered)
                    .background(Color.red)
                    .cornerRadius(10)
                    .foregroundColor(Color.white)
            }
            
        }.navigationTitle("Login")
       
        
    }
    func handleLogin(){
        print("Handle login")
        print(username)
        let currentUser = getUserFromDefaults(username: username)
        print(currentUser)
        //Compare hashed password
        if currentUser.username == ""{
            usernameNotFound = true
            print("username not found")
        }
        else{
            let hashedPassword = hashPassword(password)
            if hashedPassword != currentUser.hashedPassword{
                incorrectPassword = true
                print("wrong password")
                print(hashedPassword)
                print(currentUser.hashedPassword)
                //print(UserDefaults.standard.dictionaryRepresentation())
            }
            else{
                //Correct password; replace user and complete login
                print("signing in")
                user.name = currentUser.name
                user.username = currentUser.username
                user.hashedPassword = currentUser.hashedPassword
                user.memories = currentUser.memories
                
            }
        }
        showingLogin = false
    }
    func hashPassword(_ password: String) -> String {
        let hash = SHA256.hash(data: Data(password.utf8))
        return hash.compactMap { String(format: "%02x", $0) }.joined()
    }
    func dismiss(){
        showingLogin = false
    }
}
