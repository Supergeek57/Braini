import SwiftUI

struct AboutView: View{
    @Binding var user: User
    @Binding var showingLibrary: Bool
    @Binding var libraryFilled: Bool
    var body: some View{
        if user.name != "" {
            HStack{
                Text("Welcome to Braini, ")
                    .font(.largeTitle)
                Text("\(user.name) 🧠")
                    .font(.largeTitle)
                    .fontWeight(.semibold)
                    .foregroundColor(Color.indigo)
                
            }.padding(.bottom, 20)
                .onAppear{showingLibrary = false}
        }
        else {
            HStack{
                Text("Welcome to")
                    .font(.largeTitle)
                Text("Braini 🧠")
                    .font(.largeTitle)
                    .fontWeight(.semibold)
                    .foregroundColor(Color.indigo)
                
            }.padding(.bottom, 20)
                .onAppear{showingLibrary = false}
        }
    
        VStack{
            HStack{
                Text("The image-based memory game for")
                    .font(.title)
                    .fontWeight(.semibold)
                Text("everyone")
                    .font(.title)
                    .foregroundColor(Color.indigo)
                    .fontWeight(.semibold)
            }.padding(.bottom, 20)
            Text("Keep running into someone but can't remember their name?")
                .padding(.bottom, 10)
                .animation(.spring())
            Text("Need to memorize cell anatomy diagrams for tomorrow's bio exam?")
                .padding(.bottom, 10)
            Text("We got you!")
                .padding(.bottom, 20)
                .font(.title)
                .fontWeight(.semibold)
            Text("Build your memory by playing a simple game where you match names with pictures. It's easy and fun!")
                .padding(.bottom, 10)
            //Text("Just import some photos, give them names, and we'll do the rest. At the end of your session, we'll show you easy-to-digest data on your speed and accuracy.")
                //.padding(.bottom, 10)
            //Text("If you're signed in, your photo library will be saved locally on your device. You can also play as a guest, but your photo library will only be retained until you close the app.")
                //.padding(.bottom, 20)
            Text("Click below to go to your Braini Library and choose the photos you want to play with.")
                .padding(.bottom, 20)
            NavigationLink(destination: LibraryView(user: $user, showingLibrary: $showingLibrary, libraryFilled: $libraryFilled), isActive: $showingLibrary){
                Button(action: {showLibrary()}) {
                    Text("Go to Braini Library")
                        .frame(width: 300, height: 75)
                        .font(.title)
                }.background(Color.indigo)
                    .cornerRadius(10)
                    .foregroundColor(Color.white)
            }
                
        }
        
      
        
    }
    
    func showLibrary(){
        showingLibrary = true
    }
}

