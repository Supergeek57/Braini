import SwiftUI
import Foundation
import PhotosUI

struct ContentView: View {
    //Create empty user to start
    @State private var user = User(memories: [])
    @State private var showingLibrary = false
    @Binding var libraryFilled: Bool
    var body: some View {
        NavigationSplitView {
            List {
                //NavigationLink{
                //    AboutView(user: $user, showingLibrary: $showingLibrary, libraryFilled: $libraryFilled)
                //} label:{
                //    Label("About", systemImage: "magnifyingglass")
                //}
                NavigationLink{
                    MainGameView(user: $user, showingLibrary: $showingLibrary, libraryFilled: $libraryFilled)
                } label:{
                    Label("Play", systemImage: "brain")
                }
                NavigationLink{
                    LibraryView(user: $user, showingLibrary: $showingLibrary, libraryFilled: $libraryFilled)
                } label:{
                    Label("My Library", systemImage: "books.vertical")
                }
            }
            .navigationTitle("Braini")
        } detail: {
            MainGameView(user: $user, showingLibrary: $showingLibrary, libraryFilled: $libraryFilled)
        }.onAppear {
            if(user.memories == [] && user.newUser == true){
                fillLibrary()
                user.newUser = false
                saveUserToDefaults(user: user)
            }
        }
    }
    
    func fillLibrary(){
        if user.memories == [] && libraryFilled == false {
            if let seattle_ui_image = UIImage.init(named: "seattle_unsplash"){
                addPicFromAssets(img: seattle_ui_image, name: "Seattle")
            }
            if let cupertino_ui_image = UIImage.init(named: "cupertino_unsplash"){
                addPicFromAssets(img: cupertino_ui_image, name: "Cupertino")
            }
            if let nyc_ui_image = UIImage.init(named: "nyc_unsplash"){
                addPicFromAssets(img: nyc_ui_image, name: "New York")
            }
            
            libraryFilled = true //Only fill the library once
        }
        
    }
    
    func addPicFromAssets(img: UIImage, name: String){
        
        if let data = img.jpegData(compressionQuality: 1) {
            let filename = getDocumentsDirectory().appendingPathComponent("\(name).png")
            try? data.write(to: filename)
            let newPair = NameImagePair(name: name, imagePath: filename)
            user.memories.append(newPair)
            saveUserToDefaults(user: user)
            print(getUserFromDefaults(username: user.username))
            print(newPair.imagePath.absoluteString)
            
        }
        else{
            print("Couldn't convert to pngdata")
        }
    }
    
    func getDocumentsDirectory() -> URL {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        return paths[0]
    }
}
