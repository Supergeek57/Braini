import SwiftUI
import Photos
import Foundation

struct NameImagePair: Codable, Identifiable, Equatable{
    var id = UUID()
    var name: String
    var imagePath: URL
}
