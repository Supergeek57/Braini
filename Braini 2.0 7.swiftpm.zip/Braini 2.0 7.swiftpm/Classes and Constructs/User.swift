import SwiftUI
import Foundation

struct User: Codable{
    var name = ""
    var username = ""
    var hashedPassword = ""
    var memories: [NameImagePair]
    var newUser = true
}
