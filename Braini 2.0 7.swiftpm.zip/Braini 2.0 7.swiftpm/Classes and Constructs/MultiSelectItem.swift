import SwiftUI
//Attribution: https://stackoverflow.com/questions/57022615/select-multiple-items-in-swiftui-list

struct MultiSelectItem: View{
    var memory: NameImagePair
    var isSelected: Bool
    var action: () -> Void
    var body: some View{
        Button(action: action)
        {
            HStack{
                Image(uiImage: UIImage(contentsOfFile: memory.imagePath.path) ?? UIImage())
                    .resizable()
                    .scaledToFit()
                    .frame(width: 250, height: 250)
                    .padding(.bottom, 20)
                    .padding(.trailing, 20)
                Text(memory.name)
                    .font(.title)
                    .fontWeight(.semibold)
                if self.isSelected{
                    Spacer()
                    Image(systemName: "checkmark")
                        .resizable()
                        .frame(width: 50, height: 50)
                        .padding(.trailing, 30)
                }
                
            }
        }
    }
}
