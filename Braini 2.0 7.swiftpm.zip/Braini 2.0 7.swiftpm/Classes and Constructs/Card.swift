import SwiftUI
import PhotosUI

struct Card: Identifiable, Equatable{
    //Each card has either a name or an image
    var id = UUID()
    var cardType: Int //0 for image, 1 for name
    var pair: NameImagePair //used to check if both cards in a pair are flipped


}
