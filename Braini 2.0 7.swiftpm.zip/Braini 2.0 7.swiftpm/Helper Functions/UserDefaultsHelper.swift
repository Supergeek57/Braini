import SwiftUI

func saveUserToDefaults(user: User){
    do{
        let encoder = JSONEncoder()
        let data = try encoder.encode(user)
        UserDefaults.standard.set(data, forKey: user.username)
    } catch{
        print("Error saving to user defaults")
    }
}

func getUserFromDefaults(username: String) -> User{
    var currentUser: User? = nil
    guard let data = UserDefaults.standard.data(forKey: username) else {
        return User(memories: [])
    }
    do {
        let decoder = JSONDecoder()
        currentUser = try decoder.decode(User.self, from: data)
    } catch {
        print("Error decoding user from JSON")
    }
    return currentUser ?? User(memories: [])
}
