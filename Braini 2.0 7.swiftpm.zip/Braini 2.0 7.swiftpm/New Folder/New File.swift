//Attribution
//All photos provided for free on Unsplash

//Seattle photo: Photo by <a href="https://unsplash.com/@whatyouhide?utm_content=creditCopyText&utm_medium=referral&utm_source=unsplash">Andrea Leopardi</a> on <a href="https://unsplash.com/photos/space-needle-near-buildings-at-daytime-GV8eF1jJpSs?utm_content=creditCopyText&utm_medium=referral&utm_source=unsplash">Unsplash</a>

//Cupertino photo: Photo by <a href="https://unsplash.com/@carlesrgm?utm_content=creditCopyText&utm_medium=referral&utm_source=unsplash">Carles Rabada</a> on <a href="https://unsplash.com/photos/aerial-photography-of-round-building-GulyvMt9UwI?utm_content=creditCopyText&utm_medium=referral&utm_source=unsplash">Unsplash</a>

//NYC photo: Photo by <a href="https://unsplash.com/@mdisc?utm_content=creditCopyText&utm_medium=referral&utm_source=unsplash">Michael Discenza</a> on <a href="https://unsplash.com/photos/landscape-photo-of-new-york-empire-state-building-5omwAMDxmkU?utm_content=creditCopyText&utm_medium=referral&utm_source=unsplash">Unsplash</a>




