//MAKE SURE PHOTO ATTRIBUTION MEETS STANDARDS!

//Current login info: supergeek, 1

//Finish creating user alerts for wrong username and wrong password

//Direct users to match images to names when the game starts (they may not realize the format of the game)

//Use jpgdata instead of pngdata for stock pictures?


//Slight glitch when you click cards too fast (don't wait for them to flip back over)--shouldn't be a big issue

//Possible glitch of game ending early (after second to last card) after switching numCorrectPairs to double? Keep an eye on this


